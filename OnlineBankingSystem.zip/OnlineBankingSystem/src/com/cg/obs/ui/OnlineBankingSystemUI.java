package com.cg.obs.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.obs.dto.Customer;
import com.cg.obs.dto.Transactions;
import com.cg.obs.exception.BankException;
import com.cg.obs.service.AccountMasterServiceImpl;
import com.cg.obs.service.ServiceTrackerServiceImpl;
import com.cg.obs.service.TransactionServiceImpl;
import com.cg.obs.service.UserTableServiceImpl;

public class OnlineBankingSystemUI {

	//Service 
	static UserTableServiceImpl userService;
	static TransactionServiceImpl transactionService;
	static AccountMasterServiceImpl accountService;
	static ServiceTrackerServiceImpl serviceTrackerService;  
	//Dto
	static Customer customer;
	
	//input
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	public static void userHomePage(int userId) throws NumberFormatException, IOException
	{
		System.out.println("*****************************************HomePage***************************************************\n\n\n");
		System.out.println("\t\t Welcome "+ customer.getCustomer_name() +"  to our Online Banking System");
		try {
			int userChoice;
			System.out.println("Your Account Balance is "+ accountService.getBalance(userId));
			System.out.println("1. View Mini/Detailed statement \n2.Change in address/mobile number \n3.Request for Cheque Book \n4.Track Service request \n5.Fund Transfer \n6.Change Password");
			userChoice = Integer.parseInt(br.readLine());
			switch(userChoice)
			{
			case 1:viewMini(customer.getAccount_id());
					break;
			case 2://dao is yet to be implemented
					break;
			case 3:requestCheque(customer.getAccount_id());
					break;
			case 4:searchByAccNo(customer.getAccount_id());
					break;
			case5:
			}
		}
		catch (BankException e) 
		{
			System.out.println(e);
			//e.printStackTrace();
		}
		
	}
	

	public static void main(String[] args) throws IOException 
	{
		int userId;
		String userPassword;
		boolean userLogin;
		System.out.println("**********************************************Welcome to Online Banking System**********************************************\n\n\n");
		System.out.println("Login as : 1.User 2.Admin");
		String logger = br.readLine();
		if(logger.equals("1"))
		{
			userService = new UserTableServiceImpl();
			System.out.println("Enter your userId:	");
			userId = Integer.parseInt(br.readLine());
			try {
				if(userService.validateUserId(userId) == true)
					{
					System.out.println("Enter your password:	");
					userPassword = br.readLine();
					userLogin = userService.validateLogin(userId, userPassword);
						if(userLogin == true ) // need to add & user.lockStatus == false
							{
							customer = transactionService.getData(userId);
							userHomePage(userId);
							}
					}
			}
			catch (BankException e) 
			{
				//e.printStackTrace();
				System.out.println(e);
			}
		}
		else if(logger.equals("2"))  //admin part
		{
			
		}
		else
		{
			System.out.println("Enter a valid input");
		}
	}
	
	public static void viewMini(long accNo)
	{
		try 
		{
			ArrayList<Transactions> list=transactionService.viewMini(accNo);
			try 
			{
				for(Transactions t1:list)
					System.out.println(t1);
			}
			catch (Exception e) 
			{
					// TODO Auto-generated catch block
					e.printStackTrace();
			}
		} 
		
		catch (BankException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
	
	public static void requestCheque(long accNo)
	{
		try 
		{
			if(serviceTrackerService.requestCheque(accNo)>0)
			{
				System.out.println("Cheque Book request is raised Successfully");
			}
			else
			{
				//if cheque request is already raised
				System.out.println();
			}
		} 
		catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void searchByAccNo(long accNo) 
	{
		try 
		{
			HashMap<Integer,String> hmap=serviceTrackerService.searchByAccNo(accNo);
			Set<Entry<Integer,String>> hashSet=hmap.entrySet();
	        for(Entry entry:hashSet ) {
	            System.out.println("id="+entry.getKey()+", Status="+entry.getValue());
	        }
		} 
		catch (BankException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
